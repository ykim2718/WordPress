<?php
/**
 * WP Admin 사이드바 메뉴와 설정 화면.
 *
 * @package KeyWordCloud
 */

defined( 'ABSPATH' ) || exit;

final class KWC_Settings {

	const GROUP = 'kwc_settings_group';
	const PAGE  = 'key-word-cloud';

	/**
	 * 훅 등록.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_post_kwc_flush_cache', array( __CLASS__, 'handle_flush_cache' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( KWC_FILE ), array( __CLASS__, 'action_links' ) );
	}

	/**
	 * 활성화 시 기본값을 심는다.
	 */
	public static function on_activate() {
		if ( false === get_option( KWC_OPTION, false ) ) {
			add_option( KWC_OPTION, KWC_Defaults::options() );
		}
	}

	/**
	 * 플러그인 목록의 Settings 링크.
	 *
	 * @param array $links 기존 링크.
	 * @return array
	 */
	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=' . self::PAGE ) ) . '">설정</a>' );
		return $links;
	}

	/**
	 * 사이드바 최상위 메뉴.
	 */
	public static function add_menu() {
		add_menu_page(
			'Key Word Cloud',
			'Key Word Cloud',
			'manage_options',
			self::PAGE,
			array( __CLASS__, 'render_page' ),
			'dashicons-tagcloud',
			81
		);
	}

	/**
	 * 설정 항목 등록.
	 */
	public static function register_settings() {
		register_setting(
			self::GROUP,
			KWC_OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize' ),
				'default'           => KWC_Defaults::options(),
			)
		);

		$sections = array(
			'kwc_pick'  => '무엇을 그릴까',
			'kwc_style' => '크기와 색상',
			'kwc_cache' => '캐시',
		);
		foreach ( $sections as $id => $title ) {
			add_settings_section( $id, $title, '__return_false', self::PAGE );
		}

		$fields = array(
			array( 'language', '언어', 'kwc_pick', 'field_language' ),
			array( 'min_posts', '최소 글 수', 'kwc_pick', 'field_min_posts' ),
			array( 'max_words', '최대 topic 수', 'kwc_pick', 'field_max_words' ),
			array( 'size', '글자 크기 (px)', 'kwc_style', 'field_size' ),
			array( 'color', '색상 (적음 → 많음)', 'kwc_style', 'field_color' ),
			array( 'link_mode', 'topic 클릭 동작', 'kwc_style', 'field_link_mode' ),
			array( 'cache_ttl', '캐시 유지 시간 (초)', 'kwc_cache', 'field_cache_ttl' ),
		);
		foreach ( $fields as $field ) {
			add_settings_field( 'kwc_' . $field[0], $field[1], array( __CLASS__, $field[3] ), self::PAGE, $field[2] );
		}
	}

	/**
	 * 저장 전 검증. 값이 틀리면 고쳐 넣지 않고 에러를 띄우고 이전 값을 유지한다.
	 *
	 * @param mixed $input 폼 입력.
	 * @return array
	 */
	public static function sanitize( $input ) {
		$current = KWC_Cloud::options();

		if ( ! is_array( $input ) ) {
			add_settings_error( KWC_OPTION, 'kwc_bad_input', '설정 입력이 배열이 아니다. 저장하지 않았다.' );
			error_log( '[key-word-cloud] settings input was not an array' );
			return $current;
		}

		$out    = $current;
		$errors = array();

		$language = isset( $input['language'] ) ? (string) $input['language'] : '';
		if ( in_array( $language, array( 'en', 'ko', 'both' ), true ) ) {
			$out['language'] = $language;
		} else {
			$errors[] = '언어 값이 잘못됐다: ' . $language;
		}

		$link = isset( $input['link_mode'] ) ? (string) $input['link_mode'] : '';
		if ( in_array( $link, array( 'search', 'none' ), true ) ) {
			$out['link_mode'] = $link;
		} else {
			$errors[] = 'topic 클릭 동작 값이 잘못됐다: ' . $link;
		}

		$ints = array(
			'max_words' => array( 1, 500 ),
			'min_posts' => array( 1, 1000 ),
			'min_size'  => array( 6, 200 ),
			'max_size'  => array( 6, 200 ),
			'cache_ttl' => array( 0, 604800 ),
		);
		foreach ( $ints as $name => $range ) {
			$raw = isset( $input[ $name ] ) ? trim( (string) $input[ $name ] ) : '';
			if ( 1 !== preg_match( '/^\d+$/', $raw ) ) {
				$errors[] = $name . ' 은 정수여야 한다: ' . $raw;
				continue;
			}
			$value = (int) $raw;
			if ( $value < $range[0] || $value > $range[1] ) {
				$errors[] = sprintf( '%s 는 %d..%d 범위여야 한다: %d', $name, $range[0], $range[1], $value );
				continue;
			}
			$out[ $name ] = $value;
		}
		if ( $out['min_size'] >= $out['max_size'] ) {
			$errors[]        = sprintf( '최소 크기(%d)는 최대 크기(%d)보다 작아야 한다. 크기는 이전 값을 유지한다.', $out['min_size'], $out['max_size'] );
			$out['min_size'] = $current['min_size'];
			$out['max_size'] = $current['max_size'];
		}

		foreach ( array( 'color_start', 'color_end' ) as $name ) {
			$color = KWC_Cloud::sanitize_hex( isset( $input[ $name ] ) ? $input[ $name ] : '' );
			if ( null === $color ) {
				$errors[] = $name . ' 은 #rrggbb 형식이어야 한다.';
				continue;
			}
			$out[ $name ] = $color;
		}

		// 설정이 바뀌면 캐시된 구름은 낡은 것이다.
		$out['cache_salt'] = (int) $current['cache_salt'] + 1;

		foreach ( $errors as $i => $message ) {
			add_settings_error( KWC_OPTION, 'kwc_err_' . $i, $message );
			error_log( '[key-word-cloud] settings rejected: ' . $message );
		}

		return $out;
	}

	/**
	 * 캐시 비우기 처리.
	 */
	public static function handle_flush_cache() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( '권한이 없다.', 403 );
		}
		check_admin_referer( 'kwc_flush_cache' );
		KWC_Cloud::flush_cache();
		wp_safe_redirect( add_query_arg( 'kwc_flushed', '1', admin_url( 'admin.php?page=' . self::PAGE ) ) );
		exit;
	}

	/**
	 * 현재 설정값 하나를 읽는다.
	 *
	 * @param string $key 키.
	 * @return mixed
	 */
	private static function value( $key ) {
		$options = KWC_Cloud::options();
		return isset( $options[ $key ] ) ? $options[ $key ] : null;
	}

	/**
	 * name 속성 문자열.
	 *
	 * @param string $key 키.
	 * @return string
	 */
	private static function name( $key ) {
		return KWC_OPTION . '[' . $key . ']';
	}

	/**
	 * 숫자 입력 필드 출력.
	 *
	 * @param string $key  키.
	 * @param int    $min  최솟값.
	 * @param int    $max  최댓값.
	 * @param string $help 설명.
	 */
	private static function number_field( $key, $min, $max, $help = '' ) {
		printf(
			'<input type="number" name="%s" value="%s" min="%d" max="%d" step="1" class="small-text">',
			esc_attr( self::name( $key ) ),
			esc_attr( (string) self::value( $key ) ),
			(int) $min,
			(int) $max
		);
		if ( '' !== $help ) {
			echo ' <span class="description">' . esc_html( $help ) . '</span>';
		}
	}

	/**
	 * 라디오 묶음 출력.
	 *
	 * @param string $key    키.
	 * @param array  $labels value => label.
	 * @param string $help   설명.
	 */
	private static function radio_field( $key, array $labels, $help = '' ) {
		$current = self::value( $key );
		foreach ( $labels as $value => $label ) {
			printf(
				'<label style="margin-right:16px"><input type="radio" name="%s" value="%s" %s> %s</label>',
				esc_attr( self::name( $key ) ),
				esc_attr( $value ),
				checked( $current, $value, false ),
				esc_html( $label )
			);
		}
		if ( '' !== $help ) {
			echo '<p class="description">' . esc_html( $help ) . '</p>';
		}
	}

	// --- 필드 렌더러 ---------------------------------------------------------

	public static function field_language() {
		self::radio_field(
			'language',
			array( 'en' => '영어', 'ko' => '한글', 'both' => '혼재' ),
			'한글이 한 자라도 있으면 한글로 본다.'
		);
	}

	public static function field_min_posts() {
		self::number_field( 'min_posts', 1, 1000, '이보다 적은 글에서 온 topic 은 그리지 않는다.' );
	}

	public static function field_max_words() {
		self::number_field( 'max_words', 1, 500, '글 수 상위 N 개만 그린다.' );
	}

	public static function field_size() {
		echo '최소 ';
		self::number_field( 'min_size', 6, 200 );
		echo ' &nbsp; 최대 ';
		self::number_field( 'max_size', 6, 200 );
		echo '<p class="description">글 수에 sqrt 스케일을 적용해 두 값 사이로 배분한다.</p>';
	}

	public static function field_color() {
		foreach ( array( 'color_start' => '적은 글에서 온 topic', 'color_end' => '많은 글에서 온 topic' ) as $key => $label ) {
			printf(
				'<label style="margin-right:16px">%s <input type="color" name="%s" value="%s"></label>',
				esc_html( $label ),
				esc_attr( self::name( $key ) ),
				esc_attr( (string) self::value( $key ) )
			);
		}
	}

	public static function field_link_mode() {
		self::radio_field(
			'link_mode',
			array( 'search' => '그 말로 검색한 글 목록 열기', 'none' => '링크 없음' )
		);
	}

	public static function field_cache_ttl() {
		self::number_field( 'cache_ttl', 0, 604800, '0 이면 캐시하지 않는다. 설정을 저장하면 캐시는 자동으로 무효화된다.' );
	}

	// --- 화면 ---------------------------------------------------------------

	/**
	 * 설정 페이지.
	 */
	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( '권한이 없다.', 403 );
		}

		if ( isset( $_GET['kwc_flushed'] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>캐시를 비웠다.</p></div>';
		}

		// 최상위 메뉴 페이지는 검증 오류가 자동으로 뜨지 않는다. 직접 띄운다.
		settings_errors();

		$status = KWC_Topics::status();
		?>
		<div class="wrap">
			<h1>Key Word Cloud</h1>
			<p>숏코드: <code>[wpwordcloud]</code> — 속성으로 아래 설정을 개별 페이지에서 덮어쓸 수 있다.<br>
				예: <code>[wpwordcloud language="ko" max="30" min_posts="3" color_end="#b3202e"]</code></p>

			<h2>올라온 topic</h2>
			<?php if ( 0 === $status['count'] ) : ?>
				<p><strong>아직 없다.</strong> 파이프라인이 <code>/wp-json/key-word-cloud/v1/topics</code> 로 올려야
					구름이 그려진다.</p>
			<?php else : ?>
				<p><strong><?php echo (int) $status['count']; ?></strong>개
					<?php if ( '' !== $status['updated'] ) : ?>
						· <?php echo esc_html( $status['updated'] ); ?>
					<?php endif; ?>
					<?php if ( '' !== $status['generator'] ) : ?>
						· <?php echo esc_html( $status['generator'] ); ?>
					<?php endif; ?>
				</p>
			<?php endif; ?>

			<form method="post" action="options.php">
				<?php
				settings_fields( self::GROUP );
				do_settings_sections( self::PAGE );
				submit_button();
				?>
			</form>

			<hr>
			<h2>캐시</h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="kwc_flush_cache">
				<?php wp_nonce_field( 'kwc_flush_cache' ); ?>
				<?php submit_button( '캐시 비우기', 'secondary', 'submit', false ); ?>
			</form>

			<hr>
			<h2>미리보기</h2>
			<?php
			// 현재 설정 그대로 그려 본다. 출력은 KWC_Cloud::render 안에서 전부 이스케이프된다.
			// wp_kses_post 를 걸면 인라인 크기/색상이 지워져 미리보기가 실물과 달라진다.
			echo do_shortcode( '[wpwordcloud]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			?>
		</div>
		<?php
	}
}
